package com.example.app001;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.example.app001.DatabaseHelper;
import com.example.app001.AccountModel;

public class SQLiteAccountRepository implements Repository<AccountModel>{

	private Context context;
	public SQLiteAccountRepository(Context context){
		this.context = context;
	}
	
	
	@Override
	public void insert(AccountModel entity) {
		DatabaseHelper helper = new DatabaseHelper(context, null);
		SQLiteDatabase db = helper.getWritableDatabase();
		ContentValues values = entity.getContentValues();
		db.insert(AccountModel.TableName, null, values );
		db.close();
		helper.close();
	}

	@Override
	public void update(String Id, AccountModel entity) {
		DatabaseHelper helper = new DatabaseHelper(context, null);
		SQLiteDatabase db = helper.getWritableDatabase();
		ContentValues values = entity.getContentValues();
		db.update(AccountModel.TableName, values, "ID=?", new String[]{Id});
		db.close();
		helper.close();
	}

	@Override
	public void delete(String Id) {
		DatabaseHelper helper = new DatabaseHelper(context, null);
		SQLiteDatabase db = helper.getWritableDatabase();
		db.delete(AccountModel.TableName, "ID=?", new String[]{Id});
		db.close();
		helper.close();
	}
	
	public AccountModel findByIdByPassword(String id, String password){
		DatabaseHelper helper = new DatabaseHelper(context, null);
		SQLiteDatabase db = helper.getReadableDatabase();
		// TODO
		/*
		 * �̷� id �M password �@���d�߱���
		 * ���d�ߨ쵲�G�h�^�� AccountModel ����, �_�h  null
		 */
		Cursor cursor = db.query(AccountModel.TableName, new String[]{"ID, PASSWORD"}, "ID = ? AND PASSWORD = ?", new String[]{id, password}, null, null, "");
		cursor.moveToNext();
		if(cursor.getCount() > 0 && cursor.getColumnCount() > 0){
			AccountModel model = new AccountModel(cursor.getString(0), cursor.getString(1));
			return model;
		}else{
			return null;
		}
		//
	}
}
