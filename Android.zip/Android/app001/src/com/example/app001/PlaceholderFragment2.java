package com.example.app001;

import android.location.Location;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.GoogleMap.OnMapLongClickListener;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public  class PlaceholderFragment2 extends Fragment implements OnClickListener,LocationListener, android.location.LocationListener {
    	Button b1,b2;
        public PlaceholderFragment2() {
        }
        
        private LatLng tcu = new LatLng(23.992698999561803,121.59133739769459);

    	private MapView mapView;
    	private GoogleMap map;    	
    	TextView t1,t2;
    	@Override
    	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    		View rootView = inflater.inflate(R.layout.fragment2, container, false);
    		mapView = (MapView) rootView.findViewById(R.id.gmap);
    		mapView.onCreate(savedInstanceState);
    		t1=(TextView)rootView.findViewById(R.id.textView1);
    	    t2=(TextView)rootView.findViewById(R.id.textView2);
    	    SQLiteAccountRepository aRepository = new SQLiteAccountRepository(getActivity());
    	    AccountModel a=aRepository.findByIdByPassword(MainActivity.s1,MainActivity.s2);
    	    t1.setText("�b��: "+a.getId());
    	    b1=(Button)rootView.findViewById(R.id.button1);
            b2=(Button)rootView.findViewById(R.id.button2);            
            b1.setOnClickListener(this);
            b2.setOnClickListener(this);
            
    		return rootView;
    	}

    	@Override
    	public void onResume() {
    		super.onResume();
    		mapView.onResume();
    		int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getActivity());
    		if (resultCode == ConnectionResult.SUCCESS) {    			
    			setUpMapIfNeeded();
    		} else {
    			GooglePlayServicesUtil.getErrorDialog(resultCode, getActivity(), 1);
    		}
    	}

    	private void setUpMapIfNeeded() {
    		MapsInitializer.initialize(getActivity());
    		map = mapView.getMap();
    		if (map != null) {
    			Log.v("Main", "setUpMap");
    			setUpMap();
    		}
    	}

    	private void setUpMap() {
    		CameraUpdate center = CameraUpdateFactory.newLatLng(tcu);
    		map.moveCamera(center);
    		map.addMarker(new MarkerOptions().position(tcu));

    		CameraUpdate zoom = CameraUpdateFactory.zoomTo(16);
    		map.moveCamera(zoom);

    		map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
    		map.setMyLocationEnabled(true);
    		map.setOnMapClickListener(click);
    		map.setOnMapLongClickListener(longClick);    		
    	}

    	private OnMapClickListener click = new OnMapClickListener() {
    		@Override
    		public void onMapClick(LatLng point) {
    			Log.v("point", point.toString() + "\t" + point.latitude + "," + point.longitude);

    		}
    	};
    	
    	private OnMapLongClickListener longClick = new OnMapLongClickListener() {
    		@Override
    		public void onMapLongClick(LatLng point) {
    			CameraUpdate center = CameraUpdateFactory.newLatLng(tcu);
    			map.animateCamera(center);			
    		}
    	};    	

    	@Override
    	public void onLowMemory() {
    		super.onLowMemory();
    		mapView.onLowMemory();
    	}

    	@Override
    	public void onSaveInstanceState(Bundle outState) {
    		super.onSaveInstanceState(outState);
    		mapView.onSaveInstanceState(outState);
    	}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onLocationChanged(Location arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			if(v==b1){
				MainActivity parent = (MainActivity) this.getActivity();
				parent.switchFragmentto3();
			}
			if(v==b2){
				MainActivity parent = (MainActivity) this.getActivity();
				parent.switchFragmenttom();
			}
		}

        
    }