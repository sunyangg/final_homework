package com.example.app001;

import android.content.ContentValues;

public class AccountModel {

	public static String CreateSQL = 
			"CREATE TABLE IF NOT EXISTS Account "
			+ "(ID Text PRIMARY KEY, "
			+ "PASSWORD TEXT)";
	public static String DropSQL = "DROP TABLE Account;";
	public static String TableName = "Account";
	
	private String id;
	private String password;
	
	private ContentValues values;

	public AccountModel(String id, String password) {
		this.id = id;
		this.password = password;
		values = new ContentValues();
	}
	
	public String getId() {
		return id;
	}

	public String getPassword() {
		return password;
	}

	public ContentValues getContentValues(){
		values.clear();
		values.put("ID", id);
		values.put("PASSWORD", password);
		return values;
	}
	
	public String toString(){
		return id + "\t" + password;
	}
	
}
