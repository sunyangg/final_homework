package com.example.app001;

public interface Repository<T> {
	public void insert(T entity);
	public void update(String Id, T entity);
	public void delete(String Id);
}
