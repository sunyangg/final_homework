package com.example.app001;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public  class PlaceholderFragment1 extends Fragment implements OnClickListener{
    	Button b1,b2;
    	EditText t1,t2,t3;
        public PlaceholderFragment1() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment1, container, false);
            b1=(Button)rootView.findViewById(R.id.button1);
            b2=(Button)rootView.findViewById(R.id.button2);
            t1=(EditText)rootView.findViewById(R.id.editText1);
            t2=(EditText)rootView.findViewById(R.id.editText2);
            t3=(EditText)rootView.findViewById(R.id.editText3);
            b1.setOnClickListener(this);
            b2.setOnClickListener(this);
            return rootView;
        }

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			if(v==b1){
				if(!t1.getText().toString().equals(t2.getText().toString())){
					Toast.makeText(this.getActivity(),"�K�X�ݤ@�P",Toast.LENGTH_SHORT).show(); 
				}
				SQLiteAccountRepository aRepository = new SQLiteAccountRepository(getActivity());
				AccountModel a=new AccountModel(t1.getText().toString(),t2.getText().toString());
				aRepository.insert(a);
				MainActivity parent = (MainActivity) this.getActivity();
				parent.switchFragmenttom();
				InputMethodManager imm=(InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(t2.getWindowToken(),0);
			}
			if(v==b2){
				MainActivity parent = (MainActivity) this.getActivity();
				parent.switchFragmenttom();
				InputMethodManager imm=(InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(t2.getWindowToken(),0);
			}
			
		}
    }