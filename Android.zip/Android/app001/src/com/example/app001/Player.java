package com.example.app001;

import java.io.*;
import java.util.*;

class Player extends GamePlayer {
	public Player(String name) {
		super(name);
	}
}