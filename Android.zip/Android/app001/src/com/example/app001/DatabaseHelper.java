package com.example.app001;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.app001.AccountModel;

public class DatabaseHelper extends SQLiteOpenHelper {
	
	private final static String DATABASE_NAME = "LOGIN";
	private final static int VERSION = 1;
	
	public DatabaseHelper(Context context, CursorFactory factory) {
		super(context, DATABASE_NAME, factory, VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(AccountModel.CreateSQL);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL(AccountModel.DropSQL);
	}
}
